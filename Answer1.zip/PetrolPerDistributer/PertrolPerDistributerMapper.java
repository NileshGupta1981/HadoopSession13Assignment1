package PetrolPerDistributer;
import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Mapper;


public class PertrolPerDistributerMapper extends Mapper <LongWritable,Text,Text,DoubleWritable>
{

	DoubleWritable outvalue = new DoubleWritable();
	Text outkey = new Text();
	
	
	
	public void map(LongWritable key , Text value , Context context ) throws IOException,InterruptedException
	{
		String[] input = value.toString().split(",");
		String distributername = input[1];
		String volumesold = input[5];
		 outkey.set(distributername);
		 outvalue.set(Double.parseDouble(volumesold));
		context.write(outkey, outvalue);
		
	}
		
}
