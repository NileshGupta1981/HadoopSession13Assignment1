package PertrolPerID;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;
import org.apache.commons.collections.map.MultiValueMap;


public class PertrolPerIDReducer extends Reducer<Text,DoubleWritable,Text,DoubleWritable> 
{
	
	
	TreeMap<Double, String> treemap = new TreeMap<Double, String>();
	 MultiValueMap mvm = new MultiValueMap();
	public void reduce(Text key , Iterable<DoubleWritable> values, Context context) throws IOException, InterruptedException
	{
		
		double count = 0;
			
		for (DoubleWritable value:values){
			
			count = count+value.get();
			
		}
		
       treemap.put(count,key.toString());
		mvm.put(count,key.toString());
	 	
	}
	
	@Override
   protected void cleanup(Context context) throws IOException, InterruptedException {

		   
		Set<Double> keys = treemap.descendingKeySet();
		int count = 0;
		int count1 = 0;
		   for(Double key: keys){
          List list = (List) mvm.get(key);
           for (int j = 0; j <list.size(); j++) {
       if (count1 > 9){
    	   count = 10;
    	   break;
       }
        	   context.write( new Text((String) list.get(j)),new DoubleWritable(key));     
         count1 = count1+1;
            
           }
           //count = count + count1;
           
           if (count > 9){
        	   break;
           }
       
           }
       }
}
