package PertrolPerID;
import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;



public class PertrolPerIDMapper extends Mapper <LongWritable,Text,Text,DoubleWritable>
{

	DoubleWritable outvalue = new DoubleWritable();
	Text outkey = new Text();
	
	
	
	public void map(LongWritable key , Text value , Context context ) throws IOException,InterruptedException
	{
		String[] input = value.toString().split(",");
		String distirbuterid = input[0];
		String volumesold = input[5];
		 outkey.set(distirbuterid);
		 outvalue.set(Double.parseDouble(volumesold));
		context.write(outkey, outvalue);
		
	}
	
	
	
}
